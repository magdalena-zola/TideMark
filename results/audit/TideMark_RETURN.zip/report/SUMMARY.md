# TideMark / StableCQ — local run summary

Rows in typed corpus: 828,942,931
Event range: 2011-12-31T23:00:20 — 2024-12-31T22:58:58
Selected experimental period: 2011-12-31 — 2024-12-31 (4750 contiguous days)
Publication-period check: PASS

## Policies

| policy           |   epsilon |   alpha |   windows |   mean_delay_seconds |   median_delay_seconds |   p95_delay_seconds |   violation_fraction |   any_change_fraction |   macro_mean_relative_error |   p95_relative_error |
|:-----------------|----------:|--------:|----------:|---------------------:|-----------------------:|--------------------:|---------------------:|----------------------:|----------------------------:|---------------------:|
| fixed_global     |      0    |    0.01 |  44282269 |             3600     |                   3600 |                3600 |          0.000158348 |           0.000158348 |                 9.30322e-05 |             0        |
| oracle_offline   |      0    |    0.01 |  44282269 |              427.442 |                      0 |                3600 |          3.25187e-06 |           3.25187e-06 |                 2.01451e-06 |             0        |
| query_static     |      0    |    0.01 |  44282269 |             3600     |                   3600 |                3600 |          0.000158348 |           0.000158348 |                 9.30322e-05 |             0        |
| tidemark_context |      0    |    0.01 |  44282269 |             1099.75  |                      0 |                3600 |          0.00308776  |           0.00308776  |                 0.000432749 |             0        |
| fixed_global     |      0    |    0.05 |  44282269 |             1800     |                   1800 |                1800 |          0.0522679   |           0.0522679   |                 0.0496189   |             0.166667 |
| oracle_offline   |      0    |    0.05 |  44282269 |              427.442 |                      0 |                3600 |          3.25187e-06 |           3.25187e-06 |                 2.01451e-06 |             0        |
| query_static     |      0    |    0.05 |  44282269 |             3372.32  |                   3600 |                3600 |          0.00280135  |           0.00280135  |                 0.00273315  |             0        |
| tidemark_context |      0    |    0.05 |  44282269 |              977.981 |                      0 |                3600 |          0.00437907  |           0.00437907  |                 0.00172229  |             0        |
| fixed_global     |      0.01 |    0.01 |  44282269 |             3600     |                   3600 |                3600 |          0.00015609  |           0.000158348 |                 9.30322e-05 |             0        |
| oracle_offline   |      0.01 |    0.01 |  44282269 |              426.491 |                      0 |                3600 |          3.25187e-06 |           0.000247164 |                 3.82399e-06 |             0        |
| query_static     |      0.01 |    0.01 |  44282269 |             3600     |                   3600 |                3600 |          0.00015609  |           0.000158348 |                 9.30322e-05 |             0        |
| tidemark_context |      0.01 |    0.01 |  44282269 |             1099.75  |                      0 |                3600 |          0.00284414  |           0.00308776  |                 0.000432749 |             0        |
| fixed_global     |      0.01 |    0.05 |  44282269 |             1800     |                   1800 |                1800 |          0.0520243   |           0.0522679   |                 0.0496189   |             0.166667 |
| oracle_offline   |      0.01 |    0.05 |  44282269 |              426.491 |                      0 |                3600 |          3.25187e-06 |           0.000247164 |                 3.82399e-06 |             0        |
| query_static     |      0.01 |    0.05 |  44282269 |             3372.32  |                   3600 |                3600 |          0.00279909  |           0.00280135  |                 0.00273315  |             0        |
| tidemark_context |      0.01 |    0.05 |  44282269 |              977.981 |                      0 |                3600 |          0.00413545  |           0.00437907  |                 0.00172229  |             0        |
| fixed_global     |      0.05 |    0.01 |  44282269 |             3600     |                   3600 |                3600 |          0.000144211 |           0.000158348 |                 9.30322e-05 |             0        |
| oracle_offline   |      0.05 |    0.01 |  44282269 |              421.722 |                      0 |                3600 |          2.95829e-06 |           0.00147307  |                 3.81256e-05 |             0        |
| query_static     |      0.05 |    0.01 |  44282269 |             3600     |                   3600 |                3600 |          0.000144211 |           0.000158348 |                 9.30322e-05 |             0        |
| tidemark_context |      0.05 |    0.01 |  44282269 |             1099.75  |                      0 |                3600 |          0.00161807  |           0.00308776  |                 0.000432749 |             0        |
| fixed_global     |      0.05 |    0.05 |  44282269 |             1800     |                   1800 |                1800 |          0.0507983   |           0.0522679   |                 0.0496189   |             0.166667 |
| oracle_offline   |      0.05 |    0.05 |  44282269 |              421.722 |                      0 |                3600 |          2.95829e-06 |           0.00147307  |                 3.81256e-05 |             0        |
| query_static     |      0.05 |    0.05 |  44282269 |             3372.32  |                   3600 |                3600 |          0.00278721  |           0.00280135  |                 0.00273315  |             0        |
| tidemark_context |      0.05 |    0.05 |  44282269 |              977.981 |                      0 |                3600 |          0.00290938  |           0.00437907  |                 0.00172229  |             0        |

## Interpretation guardrails

- `ProcessedDate` is treated as an availability proxy. This is not claimed to be verified network reception time.
- `oracle_offline` is an unattainable lower bound and must not be described as an online baseline.
- Chronological train/calibration/test splits are restricted to one contiguous calendar run; disconnected periods are never merged.
- A result is publication-ready only after inspecting audit anomalies, split coverage, confidence intervals, and source timestamp semantics.