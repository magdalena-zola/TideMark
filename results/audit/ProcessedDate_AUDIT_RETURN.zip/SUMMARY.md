# ProcessedDate cadence audit

- Corpus folder: `D:\AIS\TideMark_full`
- Eligible rows in cadence scan: 827,715,328
- Fraction with ProcessedDate phase second = 0 modulo 900 s: 96.870746%
- Snapshot consistency spot-check day: 2023-09-14
- Snapshot consistency: **PASS**

## Interpretation rule

If snapshot consistency is PASS and the ProcessedDate phase/band tables show that observations arrive in concentrated 15-minute phases, the flat 0–600 s and 900–1200 s portions of the delay curves are supported as a property of the recorded availability timestamps rather than a snapshot implementation mismatch.

Inspect `snapshot_adjacent_delay_deltas.csv`, `processed_phase_15min_global.csv`, and `arrival_delay_bands_global.csv` first.

This audit does not claim that `ProcessedDate` is the physical network arrival time. It only characterizes the timestamp used in the current closed-corpus availability reconstruction.
